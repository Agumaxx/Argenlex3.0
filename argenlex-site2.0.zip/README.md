# Argenlex - IA Jurídica Argentina

Este es el sitio web inicial de Argenlex. Diseñado para estudiantes de Derecho en Argentina. Incluye:

- Página web con diseño oscuro.
- Listo para subir a GitHub y desplegar en Vercel.
